package main

import (
	"log"
	"synctool/configs"
	"synctool/database"
	"synctool/service"
)

func main() {
	config, err := configs.LoadConfig(".")
	if err != nil {
		log.Fatal("Connot load config", err)
	}

	database.Connect(config.DBSource)

	service.GetDomains()
	service.UpdatePublicDomainPrice()
}
