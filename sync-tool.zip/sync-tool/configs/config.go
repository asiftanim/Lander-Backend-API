package configs

import (
	"github.com/spf13/viper"
)

type Config struct {
	DBSource                     string `mapstructure:"DB_SOURCE"`
	ENDPOINT_AUTHORIZATION_TOKEN string `mapstructure:"ENDPOINT_AUTHORIZATION_TOKEN"`
	GET_ALL_DOMAINS              string `mapstructure:"GET_ALL_DOMAINS"`
	POST_DOMAIN_PUBLIC_PRICE     string `mapstructure:"POST_DOMAIN_PUBLIC_PRICE"`
}

func LoadConfig(path string) (config Config, err error) {
	viper.AddConfigPath(path)
	viper.SetConfigName("app")
	viper.SetConfigType("env")

	viper.AutomaticEnv()

	err = viper.ReadInConfig()
	if err != nil {
		return
	}

	err = viper.Unmarshal(&config)
	return
}
