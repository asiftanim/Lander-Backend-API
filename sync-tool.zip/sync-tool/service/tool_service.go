package service

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"synctool/configs"
	"synctool/database"
	"time"
)

type Domain struct {
	Id            uint
	DomainId      uint
	Name          string `json:"name"`
	PriceEUR      string `json:"priceEUR"`
	PriceUSD      string `json:"priceUSD"`
	IsPurchasable bool   `json:"isPurchasable"`
	ModifiedAt    time.Time
}

func GetDomains() {
	config, err := configs.LoadConfig(".")
	if err != nil {
		log.Fatal("Connot load config", err)
	}

	client := &http.Client{}
	req, _ := http.NewRequest("GET", config.GET_ALL_DOMAINS, nil)
	//req.Header.Set("Authorization", config.ENDPOINT_AUTHORIZATION_TOKEN)

	response, err := client.Do(req)
	if err != nil {
		log.Fatal(err)
	}

	defer response.Body.Close()
	res_body, err := ioutil.ReadAll(response.Body)
	if err != nil {
		log.Fatal(err)
	}

	var domain []Domain
	json.Unmarshal(res_body, &domain)

	for i := 0; i < len(domain); i++ {

		var db_domain Domain
		database.DB.Where("name = ?", domain[i].Name).First(&db_domain)

		if db_domain.Name != "" {
			db_err := database.DB.Model(&domain[i]).Where("name = ?", domain[i].Name).
				Updates(map[string]interface{}{
					"price_eur":      domain[i].PriceEUR,
					"price_usd":      domain[i].PriceUSD,
					"is_purchasable": domain[i].IsPurchasable,
					"modified_at":    time.Now(),
				}).Error

			if db_err != nil {
				fmt.Println(db_err.Error())
			} else {
				fmt.Println("Domain Updated Sucessfully")
			}

		} else {
			domain[i].ModifiedAt = time.Now()
			database.DB.Create(&domain[i])
		}
	}
}

func UpdatePublicDomainPrice() {
	//fmt.Println("UpdatePublicDomainPrice")
}
